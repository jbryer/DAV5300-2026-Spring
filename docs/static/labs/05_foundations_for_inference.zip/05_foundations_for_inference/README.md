Depoloyed app at https://openintro.shinyapps.io/sampling_distributions/.
